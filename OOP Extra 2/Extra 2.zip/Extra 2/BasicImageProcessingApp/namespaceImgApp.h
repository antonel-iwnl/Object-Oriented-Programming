#pragma once

namespace namespaceImgApp {
	class Image;
	class ImageProcessing;
	class Point;
	class Rectangle;
	class Size;
}